import { createFileRoute, Link } from "@tanstack/react-router";
import { motion, AnimatePresence } from "framer-motion";
import { useState } from "react";
import { AlertTriangle, X, Bell, ShieldAlert, ShieldCheck, Info, ExternalLink } from "lucide-react";

export const Route = createFileRoute("/alerts")({
  head: () => ({
    meta: [
      { title: "Alerts · DeepFake Shield" },
      { name: "description", content: "Real-time deepfake detection alerts and notification center." },
    ],
  }),
  component: AlertsPage,
});

const initialAlerts = [
  {
    id: 1, severity: "critical", icon: ShieldAlert, color: "red",
    title: "Potential Deepfake Detected",
    body: "interview_clip_2024.mp4 scored 18/100. GAN signature matched.",
    time: "Just now",
  },
  {
    id: 2, severity: "warning", icon: AlertTriangle, color: "yellow",
    title: "Suspicious Lip-Sync Drift",
    body: "panel_discussion.mp4 — temporal anomalies in 4 segments.",
    time: "12 min ago",
  },
  {
    id: 3, severity: "info", icon: ShieldCheck, color: "green",
    title: "Batch Scan Complete",
    body: "24 of 24 files processed. 18 authentic, 4 suspicious, 2 deepfakes.",
    time: "1 hr ago",
  },
  {
    id: 4, severity: "info", icon: Info, color: "cyan",
    title: "Model Update Available",
    body: "NeuralNet v4.3 ready — improved StyleGAN-XL detection.",
    time: "5 hr ago",
  },
];

function AlertsPage() {
  const [showPopup, setShowPopup] = useState(true);
  const [alerts, setAlerts] = useState(initialAlerts);

  return (
    <div className="relative">
      <div className="absolute inset-0 grid-bg opacity-25 pointer-events-none" />
      <div className="absolute top-10 left-1/4 w-[600px] h-[600px] rounded-full bg-cyber-red/15 blur-[140px] pointer-events-none animate-glow-pulse" />

      {/* CRITICAL POPUP */}
      <AnimatePresence>
        {showPopup && (
          <motion.div
            initial={{ opacity: 0, y: -100, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -100, scale: 0.9 }}
            transition={{ type: "spring", stiffness: 200, damping: 20 }}
            className="fixed top-20 left-1/2 -translate-x-1/2 z-50 w-[92%] max-w-md"
          >
            <div className="relative glass-strong rounded-xl p-5 border-l-4 border-cyber-red overflow-hidden"
                 style={{ boxShadow: "0 0 60px -10px var(--cyber-red), 0 20px 80px -20px black" }}>
              <div className="absolute inset-0 grid-bg opacity-20" />
              <motion.div
                className="absolute inset-0 pointer-events-none"
                animate={{ opacity: [0.15, 0.4, 0.15] }}
                transition={{ duration: 1.4, repeat: Infinity }}
                style={{ background: "radial-gradient(circle at 50% 0%, var(--cyber-red), transparent 60%)" }}
              />
              <div className="relative flex items-start gap-4">
                <motion.div
                  animate={{ scale: [1, 1.15, 1] }}
                  transition={{ duration: 1.2, repeat: Infinity }}
                  className="w-12 h-12 rounded-lg bg-cyber-red/25 flex items-center justify-center shrink-0"
                >
                  <AlertTriangle className="w-6 h-6 text-cyber-red" />
                </motion.div>
                <div className="flex-1">
                  <div className="text-[10px] uppercase tracking-[0.3em] text-cyber-red font-bold mb-1">
                    ⚠ Critical Alert
                  </div>
                  <div className="font-display font-bold text-lg neon-text-red">
                    Potential Deepfake Detected
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    The media you just analyzed shows strong indicators of synthetic generation.
                    Trust score: <span className="text-cyber-red font-bold">18/100</span>.
                  </p>
                  <div className="mt-3 flex gap-2">
                    <Link to="/result" className="px-3 py-1.5 rounded-md bg-cyber-red text-white text-[10px] uppercase tracking-widest font-bold hover:bg-cyber-red/80 transition">
                      View Report
                    </Link>
                    <button
                      onClick={() => setShowPopup(false)}
                      className="px-3 py-1.5 rounded-md glass text-[10px] uppercase tracking-widest"
                    >
                      Dismiss
                    </button>
                  </div>
                </div>
                <button onClick={() => setShowPopup(false)} className="text-muted-foreground hover:text-foreground">
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <section className="relative mx-auto max-w-5xl px-4 sm:px-6 py-12">
        <div className="flex items-end justify-between mb-8 gap-4 flex-wrap">
          <div>
            <div className="text-[10px] uppercase tracking-[0.3em] text-cyber-red mb-2 flex items-center gap-2">
              <Bell className="w-3 h-3 animate-pulse" /> Notification Center
            </div>
            <h1 className="font-display font-black text-4xl sm:text-5xl">
              Active <span className="gradient-text">Alerts</span>
            </h1>
          </div>
          <button
            onClick={() => setShowPopup(true)}
            className="px-4 py-2 rounded-md glass text-[10px] uppercase tracking-widest hover:neon-border-cyan"
          >
            Replay Demo Alert
          </button>
        </div>

        <div className="grid sm:grid-cols-3 gap-3 mb-8">
          {[
            { l: "Critical", v: 1, c: "red" },
            { l: "Warning", v: 1, c: "yellow" },
            { l: "Info", v: 2, c: "cyan" },
          ].map((s) => (
            <div key={s.l} className="glass rounded-xl p-4 flex items-center justify-between">
              <div>
                <div className="text-[10px] uppercase tracking-widest text-muted-foreground">{s.l}</div>
                <div className="font-display font-black text-2xl mt-1" style={{ color: `var(--cyber-${s.c})` }}>{s.v}</div>
              </div>
              <span className="w-2.5 h-2.5 rounded-full" style={{ background: `var(--cyber-${s.c})`, boxShadow: `0 0 12px var(--cyber-${s.c})` }} />
            </div>
          ))}
        </div>

        <div className="space-y-3">
          {alerts.map((a, i) => (
            <motion.div
              key={a.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.06 }}
              layout
              className="glass-strong rounded-xl p-4 sm:p-5 flex items-start gap-4 border-l-4 group"
              style={{ borderLeftColor: `var(--cyber-${a.color})` }}
            >
              <div className="w-11 h-11 rounded-lg flex items-center justify-center shrink-0"
                   style={{ background: `color-mix(in oklab, var(--cyber-${a.color}) 22%, transparent)` }}>
                <a.icon className="w-5 h-5" style={{ color: `var(--cyber-${a.color})` }} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="font-display font-bold text-sm uppercase tracking-wider">{a.title}</h3>
                  <span className="text-[9px] uppercase tracking-widest px-1.5 py-0.5 rounded font-bold"
                        style={{
                          background: `color-mix(in oklab, var(--cyber-${a.color}) 22%, transparent)`,
                          color: `var(--cyber-${a.color})`,
                        }}>
                    {a.severity}
                  </span>
                </div>
                <p className="text-xs text-muted-foreground mt-1">{a.body}</p>
                <div className="text-[10px] text-muted-foreground/70 mt-2 font-mono uppercase tracking-widest">{a.time}</div>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                <button className="w-8 h-8 rounded-md hover:bg-secondary/60 flex items-center justify-center text-muted-foreground hover:text-cyber-cyan">
                  <ExternalLink className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setAlerts((xs) => xs.filter((x) => x.id !== a.id))}
                  className="w-8 h-8 rounded-md hover:bg-cyber-red/20 flex items-center justify-center text-muted-foreground hover:text-cyber-red"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            </motion.div>
          ))}
          {alerts.length === 0 && (
            <div className="glass rounded-xl p-12 text-center text-sm text-muted-foreground">
              All clear. No active alerts.
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
