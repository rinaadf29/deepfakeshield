import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Shield, Upload, Brain, Eye, Lock, Zap, ArrowRight, CheckCircle2 } from "lucide-react";
import { FaceMockup } from "../components/FaceMockup";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "DeepFake Shield — Because Seeing Should Still Be Believing" },
      { name: "description", content: "Detect deepfakes in images and videos with AI-powered forensic analysis." },
    ],
  }),
  component: HomePage,
});

function HomePage() {
  return (
    <div className="relative overflow-hidden">
      {/* animated grid backdrop */}
      <div className="absolute inset-0 grid-bg-animated opacity-40 pointer-events-none" />
      <div className="absolute -top-32 left-1/2 -translate-x-1/2 w-[800px] h-[800px] rounded-full bg-cyber-purple/20 blur-[140px] pointer-events-none" />
      <div className="absolute top-40 right-0 w-[500px] h-[500px] rounded-full bg-cyber-cyan/20 blur-[120px] pointer-events-none" />

      <section className="relative mx-auto max-w-7xl px-4 sm:px-6 pt-16 sm:pt-24 pb-20">
        <div className="grid lg:grid-cols-[1.1fr_1fr] gap-12 items-center">
          <div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass text-[10px] uppercase tracking-[0.25em] mb-6"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-cyber-green animate-pulse" />
              AI Forensic Engine · v4.2 Online
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.1 }}
              className="font-display font-black text-5xl sm:text-6xl lg:text-7xl leading-[0.95] tracking-tight"
            >
              <span className="block">DETECT</span>
              <span className="block gradient-text">DEEPFAKES</span>
              <span className="block text-foreground/90">IN SECONDS.</span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.2 }}
              className="mt-6 max-w-xl text-base sm:text-lg text-muted-foreground leading-relaxed"
            >
              <span className="neon-text-cyan font-semibold">"Because seeing should still be believing."</span>
              <br />
              Upload any image or video — our neural forensics engine analyzes facial micro-patterns,
              pixel inconsistencies, and temporal artifacts to expose synthetic media.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.3 }}
              className="mt-10 flex flex-wrap gap-4"
            >
              <Link
                to="/upload"
                className="btn-cyber inline-flex items-center gap-3 px-7 py-4 rounded-md text-sm"
              >
                <Upload className="w-4 h-4" />
                Upload Media
                <ArrowRight className="w-4 h-4" />
              </Link>
              <Link
                to="/verify"
                className="inline-flex items-center gap-2 px-7 py-4 rounded-md text-sm uppercase tracking-widest font-display glass hover:neon-border-cyan transition-all"
              >
                Verify a URL
              </Link>
            </motion.div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 1, delay: 0.6 }}
              className="mt-12 grid grid-cols-3 gap-4 max-w-lg"
            >
              {[
                { v: "99.2%", l: "Accuracy" },
                { v: "1.4M+", l: "Scans" },
                { v: "<3s", l: "Avg Time" },
              ].map((s) => (
                <div key={s.l} className="glass rounded-lg p-4 text-center">
                  <div className="font-display font-bold text-2xl neon-text-cyan">{s.v}</div>
                  <div className="text-[10px] uppercase tracking-widest text-muted-foreground mt-1">{s.l}</div>
                </div>
              ))}
            </motion.div>
          </div>

          {/* face scan visual */}
          <motion.div
            initial={{ opacity: 0, scale: 0.92 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.9, delay: 0.3 }}
            className="relative"
          >
            <div className="absolute -inset-8 bg-cyber-cyan/20 blur-3xl rounded-full animate-glow-pulse" />
            <div className="relative aspect-square max-w-md mx-auto rounded-2xl overflow-hidden glass-strong p-4">
              <div className="relative w-full h-full rounded-xl overflow-hidden">
                <FaceMockup showLandmarks />
                {/* scanning line */}
                <motion.div
                  className="absolute left-0 right-0 h-[3px] z-20"
                  style={{
                    background: "linear-gradient(90deg, transparent, var(--cyber-cyan), transparent)",
                    boxShadow: "0 0 30px var(--cyber-cyan), 0 0 60px var(--cyber-cyan)",
                  }}
                  animate={{ top: ["0%", "100%", "0%"] }}
                  transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
                />
                {/* HUD overlay */}
                <div className="absolute top-3 left-3 right-3 flex justify-between text-[10px] font-mono uppercase tracking-wider text-cyber-cyan z-20">
                  <span>● REC · NEURAL.SCAN</span>
                  <span>FRAME 0428</span>
                </div>
                <div className="absolute bottom-3 left-3 right-3 flex justify-between text-[10px] font-mono uppercase tracking-wider text-cyber-cyan z-20">
                  <span>FACE-ID 7A:F2</span>
                  <span>CONF 98.4%</span>
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* feature row */}
        <div className="mt-24 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { icon: Brain, title: "Neural Forensics", desc: "Multi-modal AI trained on 12M+ synthetic samples." },
            { icon: Eye, title: "Pixel-Level Heatmaps", desc: "Visualize exactly where manipulation occurred." },
            { icon: Zap, title: "Real-Time Scanning", desc: "Sub-3-second analysis on most media." },
            { icon: Lock, title: "Zero-Trust Privacy", desc: "Files encrypted, never used for training." },
          ].map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
              className="glass rounded-xl p-6 hover:neon-border-cyan transition-all group"
            >
              <div className="w-10 h-10 rounded-lg bg-cyber-cyan/10 flex items-center justify-center mb-4 group-hover:bg-cyber-cyan/20 transition-colors">
                <f.icon className="w-5 h-5 text-cyber-cyan" />
              </div>
              <div className="font-display font-bold text-sm uppercase tracking-wider mb-2">{f.title}</div>
              <p className="text-xs text-muted-foreground leading-relaxed">{f.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>
    </div>
  );
}
