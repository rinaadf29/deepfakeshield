import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import {
  PieChart, Pie, Cell, ResponsiveContainer,
  BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid,
  AreaChart, Area,
} from "recharts";
import { ShieldCheck, ShieldAlert, ShieldX, TrendingUp, Activity, FileVideo, FileImage } from "lucide-react";

export const Route = createFileRoute("/dashboard")({
  head: () => ({
    meta: [
      { title: "Dashboard · DeepFake Shield" },
      { name: "description", content: "Analytics, history, and detection trends from your DeepFake Shield account." },
    ],
  }),
  component: DashboardPage,
});

const pieData = [
  { name: "Authentic", value: 318, color: "var(--cyber-green)" },
  { name: "Suspicious", value: 84, color: "var(--cyber-yellow)" },
  { name: "Deepfake", value: 142, color: "var(--cyber-red)" },
];

const barData = [
  { day: "Mon", real: 42, fake: 18 },
  { day: "Tue", real: 38, fake: 22 },
  { day: "Wed", real: 51, fake: 14 },
  { day: "Thu", real: 47, fake: 28 },
  { day: "Fri", real: 62, fake: 31 },
  { day: "Sat", real: 35, fake: 12 },
  { day: "Sun", real: 43, fake: 17 },
];

const trendData = Array.from({ length: 24 }).map((_, i) => ({
  h: `${i}h`,
  v: 30 + Math.sin(i / 2) * 20 + Math.random() * 15,
}));

const history = [
  { name: "interview_clip_2024.mp4", type: "video", verdict: "DEEPFAKE", score: 18, color: "red", time: "2 min ago" },
  { name: "ceo_announcement.png", type: "image", verdict: "AUTHENTIC", score: 94, color: "green", time: "12 min ago" },
  { name: "press_briefing_raw.mov", type: "video", verdict: "SUSPICIOUS", score: 58, color: "yellow", time: "44 min ago" },
  { name: "social_repost_05.jpg", type: "image", verdict: "DEEPFAKE", score: 22, color: "red", time: "1 hr ago" },
  { name: "panel_discussion.mp4", type: "video", verdict: "AUTHENTIC", score: 89, color: "green", time: "3 hr ago" },
  { name: "leaked_footage.mp4", type: "video", verdict: "AUTHENTIC", score: 91, color: "green", time: "6 hr ago" },
];

function DashboardPage() {
  return (
    <div className="relative">
      <div className="absolute inset-0 grid-bg opacity-20 pointer-events-none" />

      <section className="relative mx-auto max-w-7xl px-4 sm:px-6 py-12">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
          <div>
            <div className="text-[10px] uppercase tracking-[0.3em] text-cyber-cyan mb-2 flex items-center gap-2">
              <Activity className="w-3 h-3" /> Operations Center
            </div>
            <h1 className="font-display font-black text-4xl sm:text-5xl">
              Detection <span className="gradient-text">Dashboard</span>
            </h1>
          </div>
          <div className="flex gap-2">
            {["24H", "7D", "30D", "ALL"].map((t, i) => (
              <button
                key={t}
                className={`px-4 py-2 rounded-md text-[10px] uppercase tracking-widest font-display ${
                  i === 1 ? "bg-cyber-cyan/20 text-cyber-cyan neon-border-cyan" : "glass text-muted-foreground hover:text-foreground"
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        {/* KPI cards */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {[
            { l: "Total Scans", v: "544", icon: Activity, c: "cyan", d: "+12%" },
            { l: "Authentic", v: "318", icon: ShieldCheck, c: "green", d: "+8%" },
            { l: "Suspicious", v: "84", icon: ShieldAlert, c: "yellow", d: "+22%" },
            { l: "Deepfakes", v: "142", icon: ShieldX, c: "red", d: "+34%" },
          ].map((k, i) => (
            <motion.div
              key={k.l}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className="glass-strong rounded-xl p-5 relative overflow-hidden"
            >
              <div
                className="absolute -right-6 -top-6 w-24 h-24 rounded-full blur-2xl opacity-40"
                style={{ background: `var(--cyber-${k.c})` }}
              />
              <div className="relative flex items-start justify-between">
                <div>
                  <div className="text-[10px] uppercase tracking-[0.25em] text-muted-foreground">{k.l}</div>
                  <div className="font-display font-black text-3xl mt-2 tabular-nums" style={{ color: `var(--cyber-${k.c})` }}>
                    {k.v}
                  </div>
                  <div className="text-[10px] mt-1 flex items-center gap-1 text-cyber-green">
                    <TrendingUp className="w-3 h-3" /> {k.d} vs last week
                  </div>
                </div>
                <div className="w-10 h-10 rounded-lg flex items-center justify-center"
                     style={{ background: `color-mix(in oklab, var(--cyber-${k.c}) 18%, transparent)` }}>
                  <k.icon className="w-5 h-5" style={{ color: `var(--cyber-${k.c})` }} />
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* charts */}
        <div className="grid lg:grid-cols-3 gap-6 mb-6">
          <div className="glass-strong rounded-2xl p-6">
            <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground mb-4">
              Distribution
            </div>
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    innerRadius={55}
                    outerRadius={85}
                    paddingAngle={4}
                    dataKey="value"
                    stroke="oklch(0.14 0.03 270)"
                    strokeWidth={3}
                  >
                    {pieData.map((d, i) => <Cell key={i} fill={d.color} />)}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-2 space-y-2">
              {pieData.map((d) => (
                <div key={d.name} className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-sm" style={{ background: d.color }} />
                    <span className="text-muted-foreground">{d.name}</span>
                  </div>
                  <span className="font-mono tabular-nums">{d.value}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="lg:col-span-2 glass-strong rounded-2xl p-6">
            <div className="flex justify-between items-center mb-4">
              <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground">Detection Activity</div>
              <div className="flex gap-3 text-[10px]">
                <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-sm bg-cyber-green" /> Real</span>
                <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-sm bg-cyber-red" /> Fake</span>
              </div>
            </div>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={barData}>
                  <CartesianGrid stroke="oklch(0.32 0.06 275 / 0.3)" vertical={false} />
                  <XAxis dataKey="day" stroke="oklch(0.68 0.04 250)" fontSize={11} tickLine={false} axisLine={false} />
                  <YAxis stroke="oklch(0.68 0.04 250)" fontSize={11} tickLine={false} axisLine={false} />
                  <Tooltip
                    cursor={{ fill: "oklch(0.82 0.18 215 / 0.08)" }}
                    contentStyle={{
                      background: "oklch(0.16 0.04 270)",
                      border: "1px solid var(--cyber-cyan)",
                      borderRadius: 8,
                      fontSize: 12,
                    }}
                  />
                  <Bar dataKey="real" fill="var(--cyber-green)" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="fake" fill="var(--cyber-red)" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        <div className="glass-strong rounded-2xl p-6 mb-6">
          <div className="flex justify-between items-center mb-4">
            <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground">24h Threat Pulse</div>
            <span className="text-[10px] text-cyber-cyan">Live</span>
          </div>
          <div className="h-40">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={trendData}>
                <defs>
                  <linearGradient id="pulse" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="var(--cyber-cyan)" stopOpacity={0.7} />
                    <stop offset="100%" stopColor="var(--cyber-cyan)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <Area type="monotone" dataKey="v" stroke="var(--cyber-cyan)" strokeWidth={2} fill="url(#pulse)" />
                <XAxis dataKey="h" stroke="oklch(0.68 0.04 250)" fontSize={10} tickLine={false} axisLine={false} interval={3} />
                <Tooltip contentStyle={{ background: "oklch(0.16 0.04 270)", border: "1px solid var(--cyber-cyan)", borderRadius: 8, fontSize: 12 }} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* history table */}
        <div className="glass-strong rounded-2xl p-6">
          <div className="flex justify-between items-center mb-4">
            <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground">Recent Scans</div>
            <button className="text-[10px] uppercase tracking-widest text-cyber-cyan">View All →</button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-[10px] uppercase tracking-widest text-muted-foreground border-b border-border/50">
                  <th className="text-left py-3 pr-4 font-medium">File</th>
                  <th className="text-left py-3 pr-4 font-medium">Verdict</th>
                  <th className="text-left py-3 pr-4 font-medium">Trust</th>
                  <th className="text-right py-3 font-medium">Time</th>
                </tr>
              </thead>
              <tbody>
                {history.map((h, i) => (
                  <motion.tr
                    key={h.name}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: i * 0.04 }}
                    className="border-b border-border/30 hover:bg-secondary/30 transition"
                  >
                    <td className="py-3 pr-4">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-md bg-cyber-purple/15 flex items-center justify-center">
                          {h.type === "video" ? (
                            <FileVideo className="w-4 h-4 text-cyber-purple" />
                          ) : (
                            <FileImage className="w-4 h-4 text-cyber-purple" />
                          )}
                        </div>
                        <span className="font-mono text-xs">{h.name}</span>
                      </div>
                    </td>
                    <td className="py-3 pr-4">
                      <span
                        className="px-2.5 py-1 rounded-md text-[10px] uppercase tracking-widest font-display font-bold"
                        style={{
                          background: `color-mix(in oklab, var(--cyber-${h.color}) 18%, transparent)`,
                          color: `var(--cyber-${h.color})`,
                        }}
                      >
                        {h.verdict}
                      </span>
                    </td>
                    <td className="py-3 pr-4">
                      <div className="flex items-center gap-2 max-w-[180px]">
                        <div className="flex-1 h-1.5 rounded-full bg-secondary overflow-hidden">
                          <div className="h-full rounded-full"
                               style={{ width: `${h.score}%`, background: `var(--cyber-${h.color})` }} />
                        </div>
                        <span className="font-mono text-xs tabular-nums w-8 text-right" style={{ color: `var(--cyber-${h.color})` }}>
                          {h.score}
                        </span>
                      </div>
                    </td>
                    <td className="py-3 text-right text-xs text-muted-foreground font-mono">{h.time}</td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>
    </div>
  );
}
