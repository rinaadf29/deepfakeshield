import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { useState } from "react";
import { Link2, Globe, Shield, ExternalLink, AlertTriangle, CheckCircle2 } from "lucide-react";

export const Route = createFileRoute("/verify")({
  head: () => ({
    meta: [
      { title: "Verify URL · DeepFake Shield" },
      { name: "description", content: "Paste a video or image URL to verify its authenticity." },
    ],
  }),
  component: VerifyPage,
});

const recent = [
  { url: "twitter.com/clip/8429-sen-speech", verdict: "AUTHENTIC", score: 94, color: "green" },
  { url: "youtube.com/watch?v=ai-anchor-news", verdict: "DEEPFAKE", score: 12, color: "red" },
  { url: "tiktok.com/@user/video/77123", verdict: "SUSPICIOUS", score: 58, color: "yellow" },
  { url: "instagram.com/reel/Cx8a92Pm", verdict: "AUTHENTIC", score: 88, color: "green" },
];

function VerifyPage() {
  const [url, setUrl] = useState("");
  const [result, setResult] = useState<null | { score: number; verdict: string; color: string }>(null);
  const [loading, setLoading] = useState(false);

  const check = () => {
    if (!url) return;
    setLoading(true);
    setResult(null);
    setTimeout(() => {
      setResult({ score: 24, verdict: "DEEPFAKE DETECTED", color: "red" });
      setLoading(false);
    }, 1600);
  };

  return (
    <div className="relative">
      <div className="absolute inset-0 grid-bg opacity-25 pointer-events-none" />
      <div className="absolute top-10 right-1/4 w-[500px] h-[500px] rounded-full bg-cyber-purple/20 blur-[140px] pointer-events-none" />

      <section className="relative mx-auto max-w-5xl px-4 sm:px-6 py-16">
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 text-[10px] uppercase tracking-[0.3em] text-cyber-purple mb-4">
            <Link2 className="w-3 h-3" /> Unique Feature · URL Forensics
          </div>
          <h1 className="font-display font-black text-4xl sm:text-5xl">
            Verify Any <span className="gradient-text">Link</span>
          </h1>
          <p className="mt-3 text-muted-foreground max-w-xl mx-auto text-sm">
            Paste a link from social media or any web source. We'll fetch, scan, and score it in real time.
          </p>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-strong rounded-2xl p-6 sm:p-8"
        >
          <label className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground flex items-center gap-2 mb-3">
            <Globe className="w-3 h-3" /> Media URL
          </label>
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Link2 className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input
                type="url"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="https://twitter.com/user/status/12345..."
                className="w-full pl-11 pr-4 py-4 rounded-lg bg-secondary/60 border border-border focus:border-cyber-cyan focus:outline-none focus:ring-2 focus:ring-cyber-cyan/30 font-mono text-sm transition"
              />
            </div>
            <button
              onClick={check}
              disabled={loading}
              className="btn-cyber px-8 py-4 rounded-lg text-xs flex items-center justify-center gap-2 disabled:opacity-60"
            >
              <Shield className="w-4 h-4" />
              {loading ? "Checking..." : "Check Authenticity"}
            </button>
          </div>

          {/* result */}
          {loading && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-6 flex items-center gap-3 text-sm text-cyber-cyan">
              <div className="flex gap-1">
                {[0, 1, 2].map((i) => (
                  <motion.span key={i} className="w-2 h-2 rounded-full bg-cyber-cyan"
                    animate={{ y: [0, -6, 0] }} transition={{ duration: 0.8, repeat: Infinity, delay: i * 0.15 }} />
                ))}
              </div>
              Fetching and analyzing media…
            </motion.div>
          )}

          {result && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-6 rounded-xl p-5 border-l-4 flex items-center gap-4"
              style={{
                background: `color-mix(in oklab, var(--cyber-${result.color}) 12%, transparent)`,
                borderLeftColor: `var(--cyber-${result.color})`,
              }}
            >
              <div className="w-14 h-14 rounded-lg flex items-center justify-center"
                   style={{ background: `color-mix(in oklab, var(--cyber-${result.color}) 25%, transparent)` }}>
                <AlertTriangle className="w-7 h-7" style={{ color: `var(--cyber-${result.color})` }} />
              </div>
              <div className="flex-1">
                <div className="font-display font-black text-xl"
                     style={{ color: `var(--cyber-${result.color})`, textShadow: `0 0 18px var(--cyber-${result.color})` }}>
                  {result.verdict}
                </div>
                <div className="text-xs text-muted-foreground mt-1 font-mono truncate">{url}</div>
              </div>
              <div className="text-right">
                <div className="font-display font-black text-3xl tabular-nums"
                     style={{ color: `var(--cyber-${result.color})` }}>{result.score}</div>
                <div className="text-[10px] uppercase tracking-widest text-muted-foreground">Trust</div>
              </div>
            </motion.div>
          )}
        </motion.div>

        {/* recent checks */}
        <div className="mt-10">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display font-bold text-sm uppercase tracking-widest text-muted-foreground">
              Recent Verifications
            </h2>
            <span className="text-[10px] uppercase tracking-widest text-cyber-cyan">Live Feed</span>
          </div>
          <div className="grid sm:grid-cols-2 gap-3">
            {recent.map((r, i) => (
              <motion.div
                key={r.url}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.06 }}
                className="glass rounded-lg p-4 flex items-center gap-3 hover:neon-border-cyan transition-all"
              >
                <div className="w-8 h-8 rounded-md flex items-center justify-center shrink-0"
                     style={{ background: `color-mix(in oklab, var(--cyber-${r.color}) 20%, transparent)` }}>
                  {r.color === "green" ? (
                    <CheckCircle2 className="w-4 h-4" style={{ color: `var(--cyber-${r.color})` }} />
                  ) : (
                    <AlertTriangle className="w-4 h-4" style={{ color: `var(--cyber-${r.color})` }} />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-mono text-xs truncate text-muted-foreground">{r.url}</div>
                  <div className="text-[10px] uppercase tracking-widest mt-0.5"
                       style={{ color: `var(--cyber-${r.color})` }}>{r.verdict}</div>
                </div>
                <div className="text-right">
                  <div className="font-display font-bold text-lg tabular-nums"
                       style={{ color: `var(--cyber-${r.color})` }}>{r.score}</div>
                </div>
                <ExternalLink className="w-3.5 h-3.5 text-muted-foreground" />
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
