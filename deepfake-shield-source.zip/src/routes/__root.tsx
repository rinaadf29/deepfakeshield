import { Outlet, Link, createRootRoute, HeadContent, Scripts } from "@tanstack/react-router";
import { Nav } from "../components/Nav";

import appCss from "../styles.css?url";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "DeepFake Shield — AI-Powered Deepfake Detection" },
      { name: "description", content: "DeepFake Shield by CodeStorm uses advanced AI to detect manipulated media. Because seeing should still be believing." },
      { name: "author", content: "CodeStorm" },
      { property: "og:title", content: "DeepFake Shield — AI-Powered Deepfake Detection" },
      { property: "og:description", content: "DeepFake Shield by CodeStorm uses advanced AI to detect manipulated media. Because seeing should still be believing." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "twitter:site", content: "@Lovable" },
      { name: "twitter:title", content: "DeepFake Shield — AI-Powered Deepfake Detection" },
      { name: "twitter:description", content: "DeepFake Shield by CodeStorm uses advanced AI to detect manipulated media. Because seeing should still be believing." },
      { property: "og:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/fde8a5ed-2781-4804-834f-ce3a1d52647d/id-preview-7b37921f--6e92b3a8-362f-4bdf-be92-95582b68815b.lovable.app-1777211952736.png" },
      { name: "twitter:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/fde8a5ed-2781-4804-834f-ce3a1d52647d/id-preview-7b37921f--6e92b3a8-362f-4bdf-be92-95582b68815b.lovable.app-1777211952736.png" },
    ],
    links: [
      {
        rel: "stylesheet",
        href: appCss,
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  return (
    <div className="min-h-screen flex flex-col">
      <Nav />
      <main className="flex-1">
        <Outlet />
      </main>
      <footer className="border-t border-border/50 py-6 text-center text-[10px] uppercase tracking-[0.3em] text-muted-foreground">
        DeepFake Shield · CodeStorm · v0.1 Prototype
      </footer>
    </div>
  );
}
