import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { useEffect, useState } from "react";
import { AlertTriangle, Download, Share2, RotateCcw, ShieldAlert, Activity } from "lucide-react";
import { FaceMockup } from "../components/FaceMockup";
import { ScanFrame } from "../components/ScanFrame";
import type { DetectionResult } from "../utils/detect.functions";

export const Route = createFileRoute("/result")({
  head: () => ({
    meta: [
      { title: "Forensic Result · DeepFake Shield" },
      { name: "description", content: "Trust score, heatmap, and forensic breakdown for analyzed media." },
    ],
  }),
  component: ResultPage,
});

type StoredResult = DetectionResult & { fileName: string; dataUrl: string; at: number };

function Speedometer({ value }: { value: number }) {
  const r = 110;
  const cx = 140;
  const cy = 140;
  const startA = 150;
  const endA = 390;
  const angle = -120 + (value / 100) * 240;

  const arcPath = (start: number, end: number) => {
    const s = (start * Math.PI) / 180;
    const e = (end * Math.PI) / 180;
    const x1 = cx + r * Math.cos(s);
    const y1 = cy + r * Math.sin(s);
    const x2 = cx + r * Math.cos(e);
    const y2 = cy + r * Math.sin(e);
    const large = end - start > 180 ? 1 : 0;
    return `M ${x1} ${y1} A ${r} ${r} 0 ${large} 1 ${x2} ${y2}`;
  };

  const redEnd = startA + (40 / 100) * (endA - startA);
  const yelEnd = startA + (70 / 100) * (endA - startA);
  const needleColor = value < 40 ? "var(--cyber-red)" : value < 70 ? "var(--cyber-yellow)" : "var(--cyber-green)";

  return (
    <div className="relative w-full max-w-sm mx-auto aspect-square">
      <svg viewBox="0 0 280 280" className="w-full h-full">
        <defs>
          <filter id="glow">
            <feGaussianBlur stdDeviation="3" result="b" />
            <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
          </filter>
        </defs>
        <path d={arcPath(startA, endA)} stroke="oklch(0.24 0.05 270)" strokeWidth="22" fill="none" strokeLinecap="round" />
        <path d={arcPath(startA, redEnd)} stroke="var(--cyber-red)" strokeWidth="22" fill="none" strokeLinecap="round" filter="url(#glow)" opacity="0.95" />
        <path d={arcPath(redEnd, yelEnd)} stroke="var(--cyber-yellow)" strokeWidth="22" fill="none" strokeLinecap="round" opacity="0.6" />
        <path d={arcPath(yelEnd, endA)} stroke="var(--cyber-green)" strokeWidth="22" fill="none" strokeLinecap="round" opacity="0.6" />

        {Array.from({ length: 21 }).map((_, i) => {
          const a = (startA + (i / 20) * (endA - startA)) * (Math.PI / 180);
          const x1 = cx + (r - 18) * Math.cos(a);
          const y1 = cy + (r - 18) * Math.sin(a);
          const x2 = cx + (r - 30) * Math.cos(a);
          const y2 = cy + (r - 30) * Math.sin(a);
          return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke="oklch(0.96 0.01 240 / 0.4)" strokeWidth={i % 5 === 0 ? 2 : 1} />;
        })}

        <motion.g
          initial={{ rotate: -120 }}
          animate={{ rotate: angle }}
          transition={{ duration: 1.4, ease: "easeOut" }}
          style={{ transformOrigin: `${cx}px ${cy}px` }}
        >
          <line x1={cx} y1={cy} x2={cx} y2={cy - r + 10} stroke={needleColor} strokeWidth="3" strokeLinecap="round" filter="url(#glow)" />
          <circle cx={cx} cy={cy - r + 10} r="6" fill={needleColor} filter="url(#glow)" />
        </motion.g>

        <circle cx={cx} cy={cy} r="14" fill="oklch(0.18 0.04 270)" stroke="var(--cyber-cyan)" strokeWidth="2" />
        <circle cx={cx} cy={cy} r="4" fill="var(--cyber-cyan)" />

        <text x={cx - 90} y={cy + 70} textAnchor="middle" className="fill-cyber-red" style={{ font: "700 10px Orbitron", letterSpacing: "0.15em" }}>FAKE</text>
        <text x={cx} y={cy + 90} textAnchor="middle" className="fill-cyber-yellow" style={{ font: "700 10px Orbitron", letterSpacing: "0.15em" }}>SUSPICIOUS</text>
        <text x={cx + 90} y={cy + 70} textAnchor="middle" className="fill-cyber-green" style={{ font: "700 10px Orbitron", letterSpacing: "0.15em" }}>REAL</text>
      </svg>

      <div className="absolute inset-x-0 top-[58%] text-center pointer-events-none">
        <div
          className="font-display font-black text-5xl tabular-nums"
          style={{ color: needleColor, textShadow: `0 0 18px ${needleColor}` }}
        >
          {value}
        </div>
        <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground">Trust Score</div>
      </div>
    </div>
  );
}

function ResultPage() {
  const navigate = useNavigate();
  const [result, setResult] = useState<StoredResult | null>(null);

  useEffect(() => {
    const raw = sessionStorage.getItem("dfs.result");
    if (!raw) {
      navigate({ to: "/upload" });
      return;
    }
    try {
      setResult(JSON.parse(raw));
    } catch {
      navigate({ to: "/upload" });
    }
  }, [navigate]);

  if (!result) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="font-mono text-xs text-muted-foreground uppercase tracking-widest animate-pulse">
          Loading forensic report…
        </div>
      </div>
    );
  }

  const TRUST = result.trustScore;
  const CONFIDENCE = result.confidence;
  const verdict =
    result.verdict === "deepfake"
      ? "DEEPFAKE DETECTED"
      : result.verdict === "suspicious"
      ? "SUSPICIOUS"
      : "AUTHENTIC";
  const verdictColor = result.verdict === "deepfake" ? "red" : result.verdict === "suspicious" ? "yellow" : "green";
  const showHeatmap = result.regions.length > 0 && TRUST < 70;

  return (
    <div className="relative">
      <div className="absolute inset-0 grid-bg opacity-25 pointer-events-none" />
      <div
        className="absolute top-20 left-10 w-[500px] h-[500px] rounded-full blur-[140px] pointer-events-none animate-glow-pulse"
        style={{ background: `color-mix(in oklab, var(--cyber-${verdictColor}) 25%, transparent)` }}
      />
      <div className="absolute top-40 right-10 w-[400px] h-[400px] rounded-full bg-cyber-purple/20 blur-[120px] pointer-events-none" />

      <section className="relative mx-auto max-w-7xl px-4 sm:px-6 py-12">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-strong rounded-xl p-5 mb-8 flex flex-col sm:flex-row items-start sm:items-center gap-4 border-l-4"
          style={{ borderLeftColor: `var(--cyber-${verdictColor})` }}
        >
          <div
            className="w-12 h-12 rounded-lg flex items-center justify-center shrink-0"
            style={{ background: `color-mix(in oklab, var(--cyber-${verdictColor}) 25%, transparent)` }}
          >
            <ShieldAlert className="w-6 h-6" style={{ color: `var(--cyber-${verdictColor})` }} />
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground">Forensic Verdict</div>
            <div
              className="font-display font-black text-2xl sm:text-3xl mt-0.5"
              style={{ color: `var(--cyber-${verdictColor})`, textShadow: `0 0 20px var(--cyber-${verdictColor})` }}
            >
              {verdict}
            </div>
            <div className="mt-1 text-xs text-muted-foreground truncate">
              <span className="font-mono">{result.fileName}</span> · {result.summary}
            </div>
          </div>
          <div className="flex gap-2">
            <button className="px-4 py-2 rounded-md glass text-[10px] uppercase tracking-widest hover:neon-border-cyan flex items-center gap-2">
              <Download className="w-3.5 h-3.5" /> Report
            </button>
            <button className="px-4 py-2 rounded-md glass text-[10px] uppercase tracking-widest hover:neon-border-cyan flex items-center gap-2">
              <Share2 className="w-3.5 h-3.5" /> Share
            </button>
          </div>
        </motion.div>

        <div className="grid lg:grid-cols-[1fr_1.1fr] gap-6">
          <div className="glass-strong rounded-2xl p-6">
            <div className="flex items-center justify-between mb-2">
              <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground">Trust Meter</div>
              <div className="text-[10px] uppercase tracking-widest text-cyber-cyan">Confidence {CONFIDENCE}%</div>
            </div>
            <Speedometer value={TRUST} />
            <div className="mt-4 grid grid-cols-3 gap-2 text-center">
              {[
                { l: "Authentic", c: "green", r: "70-100" },
                { l: "Suspicious", c: "yellow", r: "40-69" },
                { l: "Deepfake", c: "red", r: "0-39" },
              ].map((s) => (
                <div key={s.l} className="rounded-lg p-2 glass">
                  <div
                    className="font-display font-bold text-[10px] uppercase tracking-widest"
                    style={{ color: `var(--cyber-${s.c})` }}
                  >
                    {s.l}
                  </div>
                  <div className="text-[10px] text-muted-foreground mt-0.5 font-mono">{s.r}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="glass-strong rounded-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground">
                {showHeatmap ? "Manipulation Heatmap" : "Analyzed Media"}
              </div>
              {showHeatmap && (
                <div className="flex items-center gap-3 text-[10px]">
                  <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-cyber-red" /> High</span>
                  <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-cyber-yellow" /> Med</span>
                </div>
              )}
            </div>
            <div className="aspect-square max-w-md mx-auto">
              <ScanFrame variant={verdictColor === "green" ? "cyan" : verdictColor === "yellow" ? "cyan" : "red"} active={false}>
                <div className="relative w-full h-full">
                  <img
                    src={result.dataUrl}
                    alt={result.fileName}
                    className="absolute inset-0 w-full h-full object-cover"
                  />
                  {showHeatmap && (
                    <div className="absolute inset-0 pointer-events-none">
                      <FaceMockup showHeatmap intensity={TRUST < 30 ? "high" : "medium"} showLandmarks={false} />
                    </div>
                  )}
                </div>
              </ScanFrame>
            </div>
            <p className="mt-4 text-xs text-muted-foreground leading-relaxed text-center">
              {result.regions.length > 0 ? (
                <>
                  Artifacts detected around{" "}
                  {result.regions.map((rg, i) => (
                    <span key={rg}>
                      <span className="text-cyber-red">{rg}</span>
                      {i < result.regions.length - 1 ? ", " : ""}
                    </span>
                  ))}
                  .
                </>
              ) : (
                <span className="text-cyber-green">No manipulation regions detected.</span>
              )}
            </p>
          </div>
        </div>

        <div className="mt-6 grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 glass-strong rounded-2xl p-6">
            <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground mb-4 flex items-center gap-2">
              <AlertTriangle className="w-3 h-3 text-cyber-red" /> Forensic Findings
            </div>
            {result.findings.length === 0 ? (
              <div className="text-sm text-muted-foreground">No notable findings.</div>
            ) : (
              <ul className="space-y-3">
                {result.findings.map((f) => {
                  const sevColor = f.severity === "high" ? "red" : f.severity === "med" ? "yellow" : "green";
                  const label = f.severity === "high" ? "Critical" : f.severity === "med" ? "Warning" : "Info";
                  return (
                    <li
                      key={f.title}
                      className="flex gap-3 p-3 rounded-lg bg-secondary/40 border border-border/50"
                    >
                      <div
                        className="w-1 rounded-full shrink-0"
                        style={{ background: `var(--cyber-${sevColor})` }}
                      />
                      <div>
                        <div className="text-sm font-semibold flex items-center gap-2 flex-wrap">
                          {f.title}
                          <span
                            className="text-[9px] uppercase tracking-widest px-1.5 py-0.5 rounded"
                            style={{
                              background: `color-mix(in oklab, var(--cyber-${sevColor}) 20%, transparent)`,
                              color: `var(--cyber-${sevColor})`,
                            }}
                          >
                            {label}
                          </span>
                        </div>
                        <div className="text-xs text-muted-foreground mt-0.5">{f.description}</div>
                      </div>
                    </li>
                  );
                })}
              </ul>
            )}
          </div>

          <div className="space-y-4">
            <div className="glass-strong rounded-2xl p-5">
              <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground mb-3 flex items-center gap-2">
                <Activity className="w-3 h-3" /> Signal Breakdown
              </div>
              {result.signals.length === 0 && (
                <div className="text-xs text-muted-foreground">No signals reported.</div>
              )}
              {result.signals.map((m) => {
                const c = m.score < 40 ? "red" : m.score < 70 ? "yellow" : "green";
                return (
                  <div key={m.label} className="mb-3 last:mb-0">
                    <div className="flex justify-between text-xs mb-1.5">
                      <span className="text-muted-foreground">{m.label}</span>
                      <span className="font-mono tabular-nums" style={{ color: `var(--cyber-${c})` }}>
                        {Math.round(m.score)}%
                      </span>
                    </div>
                    <div className="h-1.5 rounded-full bg-secondary overflow-hidden">
                      <motion.div
                        className="h-full rounded-full"
                        initial={{ width: 0 }}
                        animate={{ width: `${m.score}%` }}
                        transition={{ duration: 1.2, ease: "easeOut" }}
                        style={{ background: `var(--cyber-${c})`, boxShadow: `0 0 12px var(--cyber-${c})` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="flex flex-col gap-2">
              <Link to="/upload" className="btn-cyber inline-flex items-center justify-center gap-2 px-6 py-3 rounded-md text-xs">
                <RotateCcw className="w-4 h-4" /> Scan Another
              </Link>
              <Link to="/dashboard" className="text-center text-[10px] uppercase tracking-[0.3em] text-muted-foreground hover:text-cyber-cyan py-2">
                View Dashboard →
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
