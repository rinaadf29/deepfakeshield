import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { useRef, useState } from "react";
import { Upload, FileVideo, FileImage, X, Zap, Shield } from "lucide-react";

const formatSize = (bytes: number) => {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
};

const readAsDataURL = (file: File) =>
  new Promise<string>((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result as string);
    r.onerror = reject;
    r.readAsDataURL(file);
  });

export const Route = createFileRoute("/upload")({
  head: () => ({
    meta: [
      { title: "Upload Media · DeepFake Shield" },
      { name: "description", content: "Upload an image or video for instant deepfake forensic analysis." },
    ],
  }),
  component: UploadPage,
});

function UploadPage() {
  const [dragOver, setDragOver] = useState(false);
  const [file, setFile] = useState<{ name: string; size: string; type: "image" | "video"; mime: string; dataUrl: string } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();

  const handleFiles = async (files: FileList | null) => {
    const f = files?.[0];
    if (!f) return;
    setError(null);
    if (f.size > 10 * 1024 * 1024) {
      setError("File too large. Please use an image under 10MB for analysis.");
      return;
    }
    if (!f.type.startsWith("image/")) {
      setError("Currently only image files are supported for AI detection.");
      return;
    }
    try {
      const dataUrl = await readAsDataURL(f);
      setFile({
        name: f.name,
        size: formatSize(f.size),
        type: "image",
        mime: f.type,
        dataUrl,
      });
    } catch {
      setError("Could not read file.");
    }
  };

  const startAnalysis = () => {
    if (!file) return;
    sessionStorage.setItem(
      "dfs.pending",
      JSON.stringify({ name: file.name, mime: file.mime, dataUrl: file.dataUrl }),
    );
    sessionStorage.removeItem("dfs.result");
    navigate({ to: "/analyzing" });
  };

  return (
    <div className="relative">
      <div className="absolute inset-0 grid-bg opacity-30 pointer-events-none" />
      <div className="absolute top-20 left-1/3 w-[500px] h-[500px] rounded-full bg-cyber-purple/15 blur-[140px] pointer-events-none" />

      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => handleFiles(e.target.files)}
      />
      <section className="relative mx-auto max-w-5xl px-4 sm:px-6 py-16">
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 text-[10px] uppercase tracking-[0.3em] text-cyber-cyan mb-4">
            <Shield className="w-3 h-3" /> Step 01 / Ingestion
          </div>
          <h1 className="font-display font-black text-4xl sm:text-5xl">
            Submit Your <span className="gradient-text">Media</span>
          </h1>
          <p className="mt-3 text-muted-foreground max-w-xl mx-auto text-sm">
            Drop an image below. All files are encrypted in transit and purged after analysis.
          </p>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
          onDragLeave={() => setDragOver(false)}
          onDrop={(e) => { e.preventDefault(); setDragOver(false); handleFiles(e.dataTransfer.files); }}
          onClick={() => inputRef.current?.click()}
          className={`relative rounded-2xl glass-strong p-12 sm:p-16 cursor-pointer transition-all overflow-hidden ${
            dragOver ? "neon-border-cyan scale-[1.01]" : ""
          }`}
        >
          <div className="absolute inset-0 grid-bg opacity-20 pointer-events-none" />
          {["top-4 left-4 border-t-2 border-l-2", "top-4 right-4 border-t-2 border-r-2", "bottom-4 left-4 border-b-2 border-l-2", "bottom-4 right-4 border-b-2 border-r-2"].map((c) => (
            <div key={c} className={`absolute w-8 h-8 border-cyber-cyan ${c}`} />
          ))}

          <div className="relative flex flex-col items-center text-center">
            <motion.div
              animate={{ y: [0, -8, 0] }}
              transition={{ duration: 3, repeat: Infinity }}
              className="relative mb-6"
            >
              <div className="absolute inset-0 bg-cyber-cyan/40 blur-2xl rounded-full" />
              <div className="relative w-20 h-20 rounded-2xl glass flex items-center justify-center neon-border-cyan">
                <Upload className="w-9 h-9 text-cyber-cyan" />
              </div>
            </motion.div>

            <h2 className="font-display font-bold text-2xl mb-2">Drop image here</h2>
            <p className="text-sm text-muted-foreground mb-6">
              or <span className="text-cyber-cyan underline underline-offset-2">browse from device</span>
            </p>
            <div className="flex flex-wrap justify-center gap-2 text-[10px] uppercase tracking-widest text-muted-foreground">
              <span className="px-3 py-1 rounded-full glass">JPG · PNG · WEBP</span>
              <span className="px-3 py-1 rounded-full glass">Max 10 MB</span>
            </div>
          </div>
        </motion.div>

        {error && (
          <div className="mt-4 rounded-md border border-cyber-red/40 bg-cyber-red/10 px-4 py-3 text-xs text-cyber-red">
            {error}
          </div>
        )}

        {file && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-6 glass rounded-xl p-5 flex items-center gap-4"
          >
            <div className="w-14 h-14 rounded-lg overflow-hidden bg-cyber-purple/20 flex items-center justify-center shrink-0">
              {file.dataUrl ? (
                <img src={file.dataUrl} alt={file.name} className="w-full h-full object-cover" />
              ) : file.type === "video" ? (
                <FileVideo className="w-7 h-7 text-cyber-purple" />
              ) : (
                <FileImage className="w-7 h-7 text-cyber-purple" />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-mono text-sm truncate">{file.name}</div>
              <div className="text-xs text-muted-foreground mt-0.5 flex items-center gap-3">
                <span>{file.size}</span>
                <span className="text-cyber-green">● Ready for analysis</span>
              </div>
              <div className="mt-2 h-1 bg-secondary rounded-full overflow-hidden">
                <div className="h-full w-full bg-gradient-to-r from-cyber-cyan to-cyber-purple" />
              </div>
            </div>
            <button
              onClick={(e) => { e.stopPropagation(); setFile(null); }}
              className="w-9 h-9 rounded-lg glass hover:bg-cyber-red/20 flex items-center justify-center transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </motion.div>
        )}

        <div className="mt-8 flex justify-center">
          <button
            onClick={startAnalysis}
            disabled={!file}
            className="btn-cyber inline-flex items-center gap-3 px-10 py-4 rounded-md text-sm disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <Zap className="w-4 h-4" />
            Analyze Now
          </button>
        </div>

        <div className="mt-12 grid sm:grid-cols-3 gap-3 text-xs text-muted-foreground">
          {[
            "End-to-end encrypted upload",
            "Files purged after 24 hours",
            "Never used to train models",
          ].map((t) => (
            <div key={t} className="glass rounded-lg px-4 py-3 flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-cyber-green" />
              {t}
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
