import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import { Brain, Cpu, Eye, Activity, Fingerprint } from "lucide-react";
import { FaceMockup } from "../components/FaceMockup";
import { ScanFrame } from "../components/ScanFrame";
import { detectDeepfake } from "../utils/detect.functions";

export const Route = createFileRoute("/analyzing")({
  head: () => ({
    meta: [
      { title: "Analyzing · DeepFake Shield" },
      { name: "description", content: "Neural forensic analysis in progress." },
    ],
  }),
  component: AnalyzingPage,
});

const stages = [
  { icon: Eye, label: "Extracting facial landmarks" },
  { icon: Fingerprint, label: "Mapping biometric signature" },
  { icon: Brain, label: "Analyzing facial patterns, pixel inconsistencies…" },
  { icon: Activity, label: "Cross-referencing temporal artifacts" },
  { icon: Cpu, label: "Compiling forensic report" },
];

function AnalyzingPage() {
  const [progress, setProgress] = useState(0);
  const navigate = useNavigate();
  const startedRef = useRef(false);
  const doneRef = useRef(false);

  useEffect(() => {
    if (startedRef.current) return;
    startedRef.current = true;

    const pendingRaw = sessionStorage.getItem("dfs.pending");
    if (!pendingRaw) {
      navigate({ to: "/upload" });
      return;
    }
    const pending = JSON.parse(pendingRaw) as { name: string; mime: string; dataUrl: string };

    // kick off real detection
    detectDeepfake({ data: { dataUrl: pending.dataUrl, mimeType: pending.mime } })
      .then((result) => {
        sessionStorage.setItem(
          "dfs.result",
          JSON.stringify({ ...result, fileName: pending.name, dataUrl: pending.dataUrl, at: Date.now() }),
        );
        doneRef.current = true;
      })
      .catch((e) => {
        console.error(e);
        sessionStorage.setItem(
          "dfs.result",
          JSON.stringify({
            trustScore: 50,
            confidence: 0,
            verdict: "suspicious",
            summary: "Analysis failed. Please try again.",
            signals: [],
            findings: [{ title: "Network error", description: String(e), severity: "low" }],
            regions: [],
            fileName: pending.name,
            dataUrl: pending.dataUrl,
            at: Date.now(),
          }),
        );
        doneRef.current = true;
      });

    const id = setInterval(() => {
      setProgress((p) => {
        // creep up to 90, then wait for AI; jump to 100 when done
        if (doneRef.current) {
          if (p >= 100) {
            clearInterval(id);
            setTimeout(() => navigate({ to: "/result" }), 400);
            return 100;
          }
          return Math.min(100, p + 4);
        }
        if (p >= 90) return 90;
        return p + 1.2;
      });
    }, 60);
    return () => clearInterval(id);
  }, [navigate]);

  const stageIndex = Math.min(stages.length - 1, Math.floor((progress / 100) * stages.length));

  return (
    <div className="relative">
      <div className="absolute inset-0 grid-bg-animated opacity-30 pointer-events-none" />
      <div className="absolute top-20 left-1/2 -translate-x-1/2 w-[700px] h-[700px] rounded-full bg-cyber-cyan/20 blur-[140px] animate-glow-pulse pointer-events-none" />

      <section className="relative mx-auto max-w-6xl px-4 sm:px-6 py-12">
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 text-[10px] uppercase tracking-[0.3em] text-cyber-cyan mb-3">
            <Activity className="w-3 h-3 animate-pulse" /> Step 02 / Forensic Scan
          </div>
          <h1 className="font-display font-black text-3xl sm:text-4xl">
            Neural Engine <span className="gradient-text">Active</span>
          </h1>
        </div>

        <div className="grid lg:grid-cols-[1.2fr_1fr] gap-8">
          {/* scan area */}
          <div className="aspect-square max-w-[520px] mx-auto w-full">
            <ScanFrame variant="cyan">
              <div className="aspect-square relative">
                <FaceMockup showLandmarks />
                {/* HUD */}
                <div className="absolute top-3 left-3 right-3 flex justify-between text-[10px] font-mono uppercase tracking-wider text-cyber-cyan z-30">
                  <span>● SCAN.ACTIVE</span>
                  <span>{Math.floor(progress)}%</span>
                </div>
                <div className="absolute bottom-3 left-3 right-3 z-30">
                  <div className="text-[10px] font-mono uppercase tracking-wider text-cyber-cyan flex justify-between mb-1">
                    <span>NEURAL.NET v4.2</span>
                    <span>{(progress * 14.2).toFixed(0)} pts/s</span>
                  </div>
                </div>
              </div>
            </ScanFrame>
          </div>

          {/* status panel */}
          <div className="space-y-6">
            <div className="glass-strong rounded-xl p-6">
              <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground mb-3">
                Analysis Progress
              </div>
              <div className="flex items-end gap-3 mb-4">
                <div className="font-display font-black text-5xl gradient-text tabular-nums">
                  {Math.floor(progress)}
                </div>
                <div className="font-display text-2xl text-muted-foreground mb-1">%</div>
              </div>
              <div className="h-2 rounded-full bg-secondary overflow-hidden relative">
                <motion.div
                  className="h-full bg-gradient-to-r from-cyber-cyan via-cyber-purple to-cyber-red"
                  style={{ width: `${progress}%` }}
                />
                <div
                  className="absolute inset-y-0 w-20 opacity-50"
                  style={{
                    background: "linear-gradient(90deg, transparent, white, transparent)",
                    animation: "shimmer 1.6s linear infinite",
                    backgroundSize: "200% 100%",
                  }}
                />
              </div>
              <div className="mt-4 grid grid-cols-3 gap-2 text-center">
                {[
                  { l: "Frames", v: Math.floor(progress * 4.28) },
                  { l: "Vectors", v: Math.floor(progress * 142) },
                  { l: "Anomalies", v: Math.floor(progress / 14) },
                ].map((m) => (
                  <div key={m.l} className="bg-secondary/40 rounded-md p-2">
                    <div className="font-mono text-sm font-bold neon-text-cyan tabular-nums">{m.v}</div>
                    <div className="text-[9px] uppercase tracking-widest text-muted-foreground">{m.l}</div>
                  </div>
                ))}
              </div>
            </div>

            <div className="glass rounded-xl p-5">
              <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground mb-4">
                Pipeline Stages
              </div>
              <ul className="space-y-3">
                {stages.map((s, i) => {
                  const active = i === stageIndex;
                  const done = i < stageIndex;
                  return (
                    <li key={s.label} className="flex items-center gap-3">
                      <div
                        className={`w-7 h-7 rounded-md flex items-center justify-center shrink-0 ${
                          done
                            ? "bg-cyber-green/20 text-cyber-green"
                            : active
                            ? "bg-cyber-cyan/20 text-cyber-cyan"
                            : "bg-secondary text-muted-foreground"
                        }`}
                      >
                        <s.icon className={`w-3.5 h-3.5 ${active ? "animate-pulse" : ""}`} />
                      </div>
                      <span
                        className={`text-xs font-mono ${
                          active ? "text-foreground" : done ? "text-muted-foreground line-through" : "text-muted-foreground/60"
                        }`}
                      >
                        {s.label}
                      </span>
                      {active && (
                        <span className="ml-auto flex gap-1">
                          {[0, 1, 2].map((d) => (
                            <motion.span
                              key={d}
                              className="w-1 h-1 rounded-full bg-cyber-cyan"
                              animate={{ opacity: [0.3, 1, 0.3] }}
                              transition={{ duration: 1, repeat: Infinity, delay: d * 0.2 }}
                            />
                          ))}
                        </span>
                      )}
                    </li>
                  );
                })}
              </ul>
            </div>

            <Link
              to="/result"
              className="block text-center text-[10px] uppercase tracking-[0.3em] text-muted-foreground hover:text-cyber-cyan transition"
            >
              Skip to Result →
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
