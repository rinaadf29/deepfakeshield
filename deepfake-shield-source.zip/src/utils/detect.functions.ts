import { createServerFn } from "@tanstack/react-start";

export type DetectionResult = {
  trustScore: number; // 0 = deepfake, 100 = authentic
  confidence: number; // 0-100
  verdict: "authentic" | "suspicious" | "deepfake";
  summary: string;
  signals: { label: string; score: number }[]; // 0-100, lower = worse
  findings: { title: string; description: string; severity: "high" | "med" | "low" }[];
  regions: string[]; // e.g. ["eyes","mouth"]
};

const FALLBACK: DetectionResult = {
  trustScore: 50,
  confidence: 40,
  verdict: "suspicious",
  summary: "Analysis inconclusive — model returned no structured response.",
  signals: [
    { label: "Pixel coherence", score: 50 },
    { label: "Temporal stability", score: 50 },
    { label: "Biometric realism", score: 50 },
    { label: "Lighting consistency", score: 50 },
  ],
  findings: [
    { title: "Inconclusive analysis", description: "The forensic engine could not extract a confident signal from this media.", severity: "low" },
  ],
  regions: [],
};

export const detectDeepfake = createServerFn({ method: "POST" })
  .inputValidator((input: { dataUrl: string; mimeType: string }) => input)
  .handler(async ({ data }): Promise<DetectionResult> => {
    const apiKey = process.env.LOVABLE_API_KEY;
    if (!apiKey) {
      console.error("LOVABLE_API_KEY missing");
      return { ...FALLBACK, summary: "AI gateway not configured." };
    }

    // strip data URL prefix
    const base64 = data.dataUrl.includes(",") ? data.dataUrl.split(",")[1] : data.dataUrl;

    const systemPrompt = `You are a forensic deepfake detection expert. Analyze the provided image for signs of AI generation, deepfake manipulation, or digital tampering.

Look for:
- GAN/diffusion artifacts (StyleGAN, Stable Diffusion, Midjourney fingerprints)
- Inconsistent lighting / shadow direction
- Pixel-level warping around facial features (eyes, mouth, hairline, ears)
- Asymmetric features, malformed teeth/jewelry/hands
- Background incoherence, repeating textures
- Skin texture that is too smooth or too uniform
- Sensor noise inconsistency

Be calibrated and honest:
- Real photos of real people should score 75-95 trust.
- Obvious AI/deepfake should score 0-25.
- Only score below 40 if you have CLEAR evidence of manipulation.
- If the image looks like a normal photograph with no artifacts, score it as authentic.`;

    const body = {
      model: "google/gemini-2.5-flash",
      messages: [
        { role: "system", content: systemPrompt },
        {
          role: "user",
          content: [
            { type: "text", text: "Analyze this media for deepfake / AI generation. Return a calibrated forensic verdict." },
            { type: "image_url", image_url: { url: `data:${data.mimeType};base64,${base64}` } },
          ],
        },
      ],
      tools: [
        {
          type: "function",
          function: {
            name: "report_detection",
            description: "Return the forensic deepfake analysis result.",
            parameters: {
              type: "object",
              properties: {
                trustScore: { type: "number", description: "0-100. 0 = certainly fake/AI, 100 = certainly authentic real photo." },
                confidence: { type: "number", description: "0-100 confidence in the verdict." },
                verdict: { type: "string", enum: ["authentic", "suspicious", "deepfake"] },
                summary: { type: "string", description: "One-sentence plain-English explanation." },
                signals: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      label: { type: "string" },
                      score: { type: "number", description: "0-100, higher = more authentic-looking on this signal" },
                    },
                    required: ["label", "score"],
                  },
                },
                findings: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      title: { type: "string" },
                      description: { type: "string" },
                      severity: { type: "string", enum: ["high", "med", "low"] },
                    },
                    required: ["title", "description", "severity"],
                  },
                },
                regions: {
                  type: "array",
                  items: { type: "string" },
                  description: "Facial regions with detected artifacts, e.g. eyes, mouth, hairline. Empty if none.",
                },
              },
              required: ["trustScore", "confidence", "verdict", "summary", "signals", "findings", "regions"],
            },
          },
        },
      ],
      tool_choice: { type: "function", function: { name: "report_detection" } },
    };

    try {
      const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(body),
      });

      if (!res.ok) {
        const text = await res.text();
        console.error("AI gateway error", res.status, text);
        if (res.status === 429) return { ...FALLBACK, summary: "Rate limit reached. Try again shortly." };
        if (res.status === 402) return { ...FALLBACK, summary: "AI credits exhausted. Add credits in workspace settings." };
        return { ...FALLBACK, summary: `Gateway error ${res.status}.` };
      }

      const json = await res.json();
      const call = json.choices?.[0]?.message?.tool_calls?.[0];
      if (!call?.function?.arguments) {
        console.error("No tool call returned", JSON.stringify(json).slice(0, 500));
        return FALLBACK;
      }
      const parsed = JSON.parse(call.function.arguments) as DetectionResult;
      // clamp
      parsed.trustScore = Math.max(0, Math.min(100, Math.round(parsed.trustScore)));
      parsed.confidence = Math.max(0, Math.min(100, Math.round(parsed.confidence)));
      return parsed;
    } catch (e) {
      console.error("detectDeepfake failed", e);
      return { ...FALLBACK, summary: e instanceof Error ? e.message : "Unknown error." };
    }
  });
