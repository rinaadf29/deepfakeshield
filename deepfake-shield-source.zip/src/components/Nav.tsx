import { Link } from "@tanstack/react-router";
import { Shield, Upload, Activity, BarChart3, Link2, Bell, Home } from "lucide-react";

const items = [
  { to: "/", label: "Home", icon: Home },
  { to: "/upload", label: "Upload", icon: Upload },
  { to: "/analyzing", label: "Analyze", icon: Activity },
  { to: "/result", label: "Result", icon: Shield },
  { to: "/verify", label: "Verify Link", icon: Link2 },
  { to: "/dashboard", label: "Dashboard", icon: BarChart3 },
  { to: "/alerts", label: "Alerts", icon: Bell },
] as const;

export function Nav() {
  return (
    <header className="sticky top-0 z-40 glass-strong border-b border-border/50">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 flex items-center justify-between h-16">
        <Link to="/" className="flex items-center gap-2 group">
          <div className="relative">
            <div className="absolute inset-0 blur-md bg-cyber-cyan/60 group-hover:bg-cyber-purple/70 transition-colors" />
            <Shield className="relative w-7 h-7 text-cyber-cyan" strokeWidth={2.2} />
          </div>
          <div className="leading-tight">
            <div className="font-display font-bold tracking-widest text-sm sm:text-base">
              DEEPFAKE<span className="neon-text-cyan">SHIELD</span>
            </div>
            <div className="text-[9px] uppercase tracking-[0.3em] text-muted-foreground">
              by CodeStorm
            </div>
          </div>
        </Link>

        <nav className="hidden lg:flex items-center gap-1">
          {items.map(({ to, label, icon: Icon }) => (
            <Link
              key={to}
              to={to}
              className="px-3 py-2 rounded-md text-xs uppercase tracking-wider text-muted-foreground hover:text-foreground hover:bg-secondary/60 transition-colors flex items-center gap-1.5"
              activeProps={{
                className:
                  "px-3 py-2 rounded-md text-xs uppercase tracking-wider text-cyber-cyan bg-secondary/80 flex items-center gap-1.5 shadow-[0_0_20px_-5px_var(--cyber-cyan)]",
              }}
              activeOptions={{ exact: to === "/" }}
            >
              <Icon className="w-3.5 h-3.5" />
              {label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <div className="hidden sm:flex items-center gap-1.5 text-[10px] uppercase tracking-widest text-cyber-green">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-cyber-green opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-cyber-green" />
            </span>
            System Online
          </div>
        </div>
      </div>
    </header>
  );
}
