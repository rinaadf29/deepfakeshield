import { motion } from "framer-motion";

interface FaceMockupProps {
  showHeatmap?: boolean;
  showLandmarks?: boolean;
  intensity?: "low" | "medium" | "high";
}

/**
 * Stylized portrait built entirely from SVG — guarantees no broken images
 * and reinforces the "AI scanning a face" aesthetic.
 */
export function FaceMockup({
  showHeatmap = false,
  showLandmarks = true,
  intensity = "medium",
}: FaceMockupProps) {
  const heatStrength = intensity === "high" ? 0.85 : intensity === "medium" ? 0.55 : 0.3;

  return (
    <svg viewBox="0 0 400 400" className="w-full h-full block">
      <defs>
        <radialGradient id="bg" cx="50%" cy="40%" r="70%">
          <stop offset="0%" stopColor="oklch(0.32 0.08 280)" />
          <stop offset="100%" stopColor="oklch(0.12 0.03 270)" />
        </radialGradient>
        <linearGradient id="skin" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="oklch(0.62 0.08 50)" />
          <stop offset="100%" stopColor="oklch(0.35 0.06 30)" />
        </linearGradient>
        <radialGradient id="heatHigh" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="oklch(0.7 0.27 25)" stopOpacity={heatStrength} />
          <stop offset="100%" stopColor="oklch(0.7 0.27 25)" stopOpacity="0" />
        </radialGradient>
        <radialGradient id="heatMed" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="oklch(0.85 0.18 90)" stopOpacity={heatStrength * 0.8} />
          <stop offset="100%" stopColor="oklch(0.85 0.18 90)" stopOpacity="0" />
        </radialGradient>
      </defs>

      {/* background */}
      <rect width="400" height="400" fill="url(#bg)" />

      {/* subtle grid */}
      <g opacity="0.15" stroke="oklch(0.82 0.18 215)" strokeWidth="0.5">
        {Array.from({ length: 10 }).map((_, i) => (
          <line key={`h${i}`} x1="0" y1={i * 40} x2="400" y2={i * 40} />
        ))}
        {Array.from({ length: 10 }).map((_, i) => (
          <line key={`v${i}`} x1={i * 40} y1="0" x2={i * 40} y2="400" />
        ))}
      </g>

      {/* neck */}
      <path d="M160 320 L160 360 Q200 380 240 360 L240 320 Z" fill="url(#skin)" />

      {/* head */}
      <ellipse cx="200" cy="200" rx="95" ry="115" fill="url(#skin)" />

      {/* hair */}
      <path
        d="M105 175 Q100 100 200 90 Q300 100 295 180 Q280 140 200 135 Q120 140 105 175 Z"
        fill="oklch(0.18 0.04 280)"
      />

      {/* eyes */}
      <ellipse cx="170" cy="195" rx="14" ry="6" fill="oklch(0.95 0.01 240)" />
      <ellipse cx="230" cy="195" rx="14" ry="6" fill="oklch(0.95 0.01 240)" />
      <circle cx="170" cy="195" r="4.5" fill="oklch(0.25 0.08 230)" />
      <circle cx="230" cy="195" r="4.5" fill="oklch(0.25 0.08 230)" />
      <circle cx="171" cy="194" r="1.5" fill="white" />
      <circle cx="231" cy="194" r="1.5" fill="white" />

      {/* eyebrows */}
      <path d="M152 178 Q170 172 188 178" stroke="oklch(0.18 0.04 280)" strokeWidth="3" fill="none" strokeLinecap="round" />
      <path d="M212 178 Q230 172 248 178" stroke="oklch(0.18 0.04 280)" strokeWidth="3" fill="none" strokeLinecap="round" />

      {/* nose */}
      <path d="M200 205 Q195 235 200 250 Q205 248 210 245" stroke="oklch(0.32 0.05 30)" strokeWidth="1.5" fill="none" />

      {/* mouth */}
      <path d="M180 280 Q200 290 220 280" stroke="oklch(0.45 0.12 25)" strokeWidth="3" fill="none" strokeLinecap="round" />

      {/* heatmap overlays */}
      {showHeatmap && (
        <>
          <circle cx="170" cy="195" r="40" fill="url(#heatHigh)" />
          <circle cx="230" cy="195" r="40" fill="url(#heatHigh)" />
          <circle cx="200" cy="280" r="35" fill="url(#heatMed)" />
          <circle cx="200" cy="240" r="25" fill="url(#heatMed)" />
        </>
      )}

      {/* landmarks */}
      {showLandmarks && (
        <g fill="oklch(0.82 0.18 215)" opacity="0.9">
          {[
            [170, 195], [230, 195], [200, 230], [200, 250],
            [180, 280], [220, 280], [200, 290],
            [120, 210], [280, 210], [140, 260], [260, 260],
            [200, 105], [165, 110], [235, 110],
          ].map(([x, y], i) => (
            <g key={i}>
              <circle cx={x} cy={y} r="2.5" />
              <circle cx={x} cy={y} r="5" fill="none" stroke="oklch(0.82 0.18 215)" strokeWidth="0.5" opacity="0.5" />
            </g>
          ))}
        </g>
      )}

      {/* face frame brackets */}
      <g stroke="oklch(0.82 0.18 215)" strokeWidth="2" fill="none" opacity="0.7">
        <path d="M105 110 L105 140 M105 110 L135 110" />
        <path d="M295 110 L295 140 M295 110 L265 110" />
        <path d="M105 320 L105 290 M105 320 L135 320" />
        <path d="M295 320 L295 290 M295 320 L265 320" />
      </g>
    </svg>
  );
}
