import { motion } from "framer-motion";

interface ScanFrameProps {
  children: React.ReactNode;
  active?: boolean;
  variant?: "cyan" | "red" | "green" | "yellow";
}

export function ScanFrame({ children, active = true, variant = "cyan" }: ScanFrameProps) {
  const colorVar = `var(--cyber-${variant})`;
  return (
    <div
      className="relative rounded-xl overflow-hidden"
      style={{
        boxShadow: `0 0 0 1px color-mix(in oklab, ${colorVar} 50%, transparent), 0 0 60px -10px ${colorVar}`,
      }}
    >
      {/* corners */}
      {[
        "top-0 left-0 border-t-2 border-l-2",
        "top-0 right-0 border-t-2 border-r-2",
        "bottom-0 left-0 border-b-2 border-l-2",
        "bottom-0 right-0 border-b-2 border-r-2",
      ].map((cls) => (
        <div
          key={cls}
          className={`absolute w-6 h-6 z-20 ${cls}`}
          style={{ borderColor: colorVar }}
        />
      ))}

      <div className="relative z-10">{children}</div>

      {active && (
        <>
          <motion.div
            className="absolute left-0 right-0 h-[2px] z-20 pointer-events-none"
            style={{
              background: `linear-gradient(90deg, transparent, ${colorVar}, transparent)`,
              boxShadow: `0 0 20px ${colorVar}, 0 0 40px ${colorVar}`,
            }}
            initial={{ top: "0%" }}
            animate={{ top: ["0%", "100%", "0%"] }}
            transition={{ duration: 2.6, repeat: Infinity, ease: "linear" }}
          />
          <div
            className="absolute inset-0 z-10 pointer-events-none opacity-40"
            style={{
              backgroundImage: `repeating-linear-gradient(0deg, transparent 0, transparent 3px, color-mix(in oklab, ${colorVar} 10%, transparent) 3px, color-mix(in oklab, ${colorVar} 10%, transparent) 4px)`,
            }}
          />
        </>
      )}
    </div>
  );
}
